---
name: rea-setup
description: REA (Reverse Engineer Anything, github.com/morluto/rea) をこのセッションのコンテナにインストールし、Claude Code の MCP サーバーとして登録する。ユーザーが「REA を使いたい」「REA 入れて」「/rea-setup」と言ったとき、または rea コマンドや REA の MCP ツールが見つからないときに使う。
---

# REA セットアップ

1. 既に入っているか確認する: `rea --version && claude mcp get rea`。
   どちらも成功して `Connected` と出ていれば手順 3 へ進む。
2. 下のスクリプトをそのまま Bash で実行する（数分かかるのでタイムアウトは 10 分にする）。
   失敗したら、失敗したコマンドとエラーをそのままユーザーに伝える。

```bash
set -euo pipefail
NODE_DIR=/opt/node24

# REA が要求する Node.js 24 系の最新版を公式サイトから取得（チェックサム検証あり）
if [ ! -x "$NODE_DIR/bin/node" ]; then
  V=$(curl -fsSL https://nodejs.org/dist/index.json \
    | python3 -c "import json,sys;print([r['version'] for r in json.load(sys.stdin) if r['version'].startswith('v24.')][0])")
  TMP=$(mktemp -d)
  curl -fsSL -o "$TMP/node.tar.xz" "https://nodejs.org/dist/$V/node-$V-linux-x64.tar.xz"
  echo "$(curl -fsSL "https://nodejs.org/dist/$V/SHASUMS256.txt" | grep " node-$V-linux-x64.tar.xz\$" | cut -d' ' -f1)  $TMP/node.tar.xz" | sha256sum -c -
  mkdir -p "$NODE_DIR"
  tar -xJf "$TMP/node.tar.xz" -C "$NODE_DIR" --strip-components=1
  rm -rf "$TMP"
fi

# REA を Node 24 側にインストール（システムの Node には触らない）
PATH="$NODE_DIR/bin:$PATH" npm install --global --prefix "$NODE_DIR" rea-agents@latest

# どこから呼ばれても Node 24 で動く rea コマンドを用意（既存のリンクを先に消す）
rm -f /usr/local/bin/rea
cat > /usr/local/bin/rea <<EOF
#!/bin/sh
PATH="$NODE_DIR/bin:\$PATH" exec "$NODE_DIR/bin/node" "$NODE_DIR/lib/node_modules/rea-agents/scripts/rea.mjs" "\$@"
EOF
chmod +x /usr/local/bin/rea

# Claude Code 用の REA スキルを入れ、MCP サーバーを rea コマンド経由で登録
rea setup --yes --skill-client claude_code --json > /tmp/rea-setup.json || true
claude mcp remove --scope user rea >/dev/null 2>&1 || true
claude mcp add --scope user rea -- /usr/local/bin/rea mcp

rea --version
claude mcp get rea
```

3. 結果をユーザーに日本語で短く伝える:
   - `rea` コマンドはすぐ使える（例: `rea --help`、`rea analyze-javascript-application <パス> --json`）。
   - REA の MCP ツールを Claude から直接呼べるのは、次に始めるセッションから。今のセッションでは `rea` コマンドを Bash で使う。
   - Hopper / Ghidra / IDA は入れていないので、ネイティブバイナリの解析はできない。JavaScript・Electron・Web サイトの解析はできる。
